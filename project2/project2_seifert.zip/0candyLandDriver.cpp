// CSCI 1300 Fall 2023
// Author: Brooke Seifert
// TA: AC
// Project 2
#include "Board.h"
#include "Tile.h"
#include "Player.h"
#include "CandyStore.h"
#include "CandyLand.h"

#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <cassert>

using namespace std;

int main()
{
    srand(time(0));
    
    CandyLand game; 
    Board board;
    Player p1;
    Player p2;
    Player players[2] = {p1, p2};
    game.startGame(players); //loads all candies, characters, and sets players - first candy store visit 
    game.playGame(board, players); //game play with turns and ending 
    
    return 0;
}

//decrease stamina done 
//same tile constraints done
//fix ending display for the end with a TA done 
//do the candys we laod for the charcters need the attributes loaded as well done
//calling on special tiles done
//using candies - remove not working is only issue
//calling on special tiles - remove not working for gingerbread
//dont allow the players to choose the same characters done
//rock paper scissors done
//remove candy is wokring done
//place treasures done
//place candy stores done
//dont remove from candy stores done 
//visit candystore done
//write to file stats candies done
//Game stats should be displayed as instructed at each turn done
//rock paper sciors computer needs to choce a different thing each time done
//place calamities done
//robber repell upercase done
//not my updated candy inventory when i land on a candy store during game play, the inventory is edited in visit and reflected back actually okay
//second candy store is using the updated invenotry done
//first question for riddle never takes the correct answer done
//make it so loaded candys into candy stores dont repeat done
//candy store within ice cream shop ----- wewrite ice cream shop done
//type sort candies into candy store done
//random display stats somewhere doene 
//cant use candy you dont have done

//82 is the golden number according to indexing 



